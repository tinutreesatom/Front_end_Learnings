import { Directive, ElementRef, HostListener} from '@angular/core';
import {Input} from '@angular/core';

@Directive({
  selector: '[appHighlight]',
  standalone: true
})
export class HighlightDirective {
  // constructor(private el: ElementRef) { 
  //   // this.el.nativeElement.style.color = 'red';
  //   this.el.nativeElement.style.backgroundColor = 'yellow';
  // }


  // @HostListener('mouseenter') onMouseEnter() {
  //   this.highlight('yellow');
  // }
  // @HostListener('mouseleave') onMouseLeave() {
  //   this.highlight('');
  // }

  // private highlight(color: string) {
  //   this.el.nativeElement.style.backgroundColor = color;
  // }

  // constructor(private el: ElementRef) {
  //   this.el.nativeElement.style.color = 'blue';
  //   this.el.nativeElement.style.fontWeight = 'bold';
  // }

  // @HostListener('mouseleave') onMouseLeave() {
  //     this.el.nativeElement.style.backgroundColor = 'red';
  // }

  @Input() color: string = '';
  // @Input() backgroundColor: string = '';
  constructor(private el: ElementRef) {
      this.el.nativeElement.style.fontWeight = 'bold';
  }
  @HostListener('mouseenter') onMouseEnter() {
      this.el.nativeElement.style.color = this.color;
      // this.el.nativeElement.style.backgroundColor = this.backgroundColor;
  }
}
