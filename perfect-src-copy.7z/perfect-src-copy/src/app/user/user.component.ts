// import { Component, computed,signal } from '@angular/core'; // signal to notify changes in class property // computed uses with signal use with getters
import { Component, Input, input, computed, EventEmitter, Output, output } from '@angular/core';
// import { DUMMY_USERS } from '../dummy-users';
// const randomIndex = Math.floor(Math.random() * DUMMY_USERS.length);

import { User } from './user.model';
import { CardComponent } from '../shared/card/card.component';
/**
 * For Types
import { type User } from './user.model';
 * 
 */

/**
 *  Type Definition
type User = {
  id: string;
  name: string;
  avatar: string;
}
 */

/**
 *  Interface definition
 * 
interface User {
  id: string;
  name: string;
  avatar: string;
}
 */

@Component({
  selector: 'app-user',
  standalone: true,
  imports:[CardComponent],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent { 
  @Input({ required: true }) user! : User;
  @Input({ required: true }) selected!: boolean;
  // @Input({required: true}) id!: string;
  // @Input({required : true}) avatar!: string ;    // Using input decorator
  // @Input() name!: string;

  // id = input.required<string>();
  // avatar = input.required<string>();
  // name = input.required<string>();

  @Output() select = new EventEmitter<string>();       // here select is the custom event

  // select = output<string>()     //output fn
 
 get imagePath() {           // getters cannot be direcly use with signal
  return 'assets/users/' + this.user.avatar;
 }

  /*   //  input signals
  // avatar = input();    //simple input signal
  // avatar = input<string>();   //input signal with generic type
  avatar = input.required<string>();
  name = input.required<string>();

  imagePath = computed(() => 'assets/users/' + this.avatar())
  get imagePath() {
    return 'assets/users/' + this.avatar();
  }

 */

   /* Selection of random users 
  selectedUser = signal(DUMMY_USERS[randomIndex]);
  imagePath = computed(() => 'assets/users/' + this.selectedUser().avatar)
  */


 

 onSelectUser() {

  /* Selection of random users 
  const randomIndex = Math.floor(Math.random() * DUMMY_USERS.length);
  this.selectedUser.set(DUMMY_USERS[randomIndex]);        // set method of signal to set changed value (Angular 16 onwards)
  // this.selectedUser = DUMMY_USERS[randomIndex];           // normal assigning
  
  */

  // With @Output decorator
  this.select.emit(this.user.id)
  
 }
  
}
